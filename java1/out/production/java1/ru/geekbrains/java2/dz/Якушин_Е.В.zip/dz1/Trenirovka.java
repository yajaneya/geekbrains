package ru.geekbrains.java1.dz_2.dz1;

// интерфейс, отвечающий за тренировки

public interface Trenirovka {

    void tren_polosa();

//    int tren_prepyatstvie (int prep);  - на перспективу: реализация тренировки по одному препятствию

}
